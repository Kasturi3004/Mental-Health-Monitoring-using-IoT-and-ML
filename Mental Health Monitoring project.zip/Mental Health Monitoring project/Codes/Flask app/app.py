from flask import Flask, render_template
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import confusion_matrix
import os

app = Flask(__name__)

# Prepare the data and model
data = pd.read_csv("merged_sensor_data.csv")
features = ["accX", "accY", "accZ", "gsr", "gyroX", "gyroY", "gyroZ", "humidity", "pulse", "temperature", "timestamp"]
target = "state"
X = data[features]
y = data[target]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
clf = RandomForestClassifier(random_state=42, n_estimators=100)
clf.fit(X_train, y_train)
y_pred = clf.predict(X_test)

# Create output directory for images
os.makedirs("static", exist_ok=True)

# Plot State Distribution
plt.figure(figsize=(8,4))
sns.countplot(data=data, x='state')
plt.title("Distribution of States")
plt.savefig("static/state_distribution.png")
plt.close()

# Confusion Matrix
cm = confusion_matrix(y_test, y_pred)
plt.figure(figsize=(8,6))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=clf.classes_, yticklabels=clf.classes_)
plt.title("Confusion Matrix")
plt.savefig("static/confusion_matrix.png")
plt.close()

# Feature Importances
feature_names = X.columns
importances = clf.feature_importances_
feat_imp_df = pd.DataFrame({'Feature': feature_names, 'Importance': importances}).sort_values(by='Importance', ascending=False)
plt.figure(figsize=(10,6))
sns.barplot(x='Importance', y='Feature', data=feat_imp_df)
plt.title("Feature Importances")
plt.savefig("static/feature_importance.png")
plt.close()

@app.route("/")
def index():
    return render_template("index1.html")

if __name__ == "__main__":
    app.run(debug=True)
